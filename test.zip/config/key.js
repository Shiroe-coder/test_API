module.exports = {
    mongoURI :"mongodb+srv://admin:admin@cluster0.84mggf6.mongodb.net/?retryWrites=true&w=majority",
};